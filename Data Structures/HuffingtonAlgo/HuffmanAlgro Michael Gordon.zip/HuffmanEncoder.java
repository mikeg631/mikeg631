
/**
 * Write a description of class Huffman here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.io.*;
import java.util.Stack;
import java.util.Collections;

public class HuffmanEncoder implements HuffmanCoding
{
    //take a file as input and create a table with characters and frequencies
    //print the characters and frequencies
    public String getFrequencies(File inputFile) throws FileNotFoundException
    {
        String s = "";
        int[] frequencies = new int[95];
        BufferedReader buffer = new BufferedReader( new InputStreamReader( new FileInputStream(inputFile)));
        int c = 0;
        try{
            while((c = buffer.read()) != -1) {
                if(c > 31)
                    frequencies[c-32]++;
            }
        }
        catch(IOException e )
        {
        }

        for(int i = 0; i < 95; i++)
        {
            if(frequencies[i] != 0)
                s  += (char)(i+32) + " " + frequencies[i] + "\n";
        }

        return s;
    }

    //take a file as input and create a Huffman Tree
    public HuffTree buildTree(File inputFile) throws FileNotFoundException, Exception
    {
        Heap minHeap = new Heap();
        BufferedReader buffer = new BufferedReader( new InputStreamReader( new FileInputStream(inputFile)));
        String s = getFrequencies(inputFile);
        String str;
        BufferedReader reader = new BufferedReader(new StringReader(s));
        try {

            while ((str = reader.readLine()) != null) {
                if (str.length() > 0) 
                {
                    minHeap.insert(new HuffTree(str.charAt(0), Integer.parseInt(str.substring(2))));
                }
            }

        } catch(IOException e) {
            e.printStackTrace();
        }

        HuffTree tmp1, tmp2, tmp3 = null;
        while (minHeap.size() > 1) { // While two items left
            tmp1 = minHeap.remove();
            tmp2 = minHeap.remove();
            tmp3 = new HuffTree(tmp1.root(), tmp2.root(),
                tmp1.weight() + tmp2.weight());
            minHeap.insert(tmp3);   // Return new tree to heap
        }

        return tmp3;   
    }

    //take a file and a HuffTree and encode the file.  
    //output a string of 1's and 0's representing the file
    public String encodeFile(File inputFile, HuffTree huffTree) throws FileNotFoundException
    {
        BufferedReader buffer = new BufferedReader( new InputStreamReader( new FileInputStream(inputFile)));
        
        String temp = "";
        String str;
        
        try {
            String s = traverseHuffmanTree(huffTree);
            
            int c = 0;
            while((c = buffer.read()) != -1) {
                BufferedReader reader = new BufferedReader(new StringReader(s));
                if(c > 31)
                {
                    while ((str = reader.readLine()) != null) {
                        if (str.length() > 0) 
                        {
                            if(str.charAt(0) == c)
                                temp += str.substring(2);
                        }
                    }
                }
            }

        } catch(IOException e) {
            e.printStackTrace();
        }
        catch(Exception d) {
            d.printStackTrace();
        }

        return temp;
    }

    //take a String and HuffTree and output the decoded words
    public String decodeFile(String code, HuffTree huffTree) throws Exception
    {
        BufferedReader buffer = new BufferedReader( new StringReader(code));
        
        String temp = "";
        String str;
        
        try {
            String s = traverseHuffmanTree(huffTree);
            
            int c = 0;
            String temp2 = "";
            while((c = buffer.read()) != -1) {
                BufferedReader reader = new BufferedReader(new StringReader(s));
                if(c > 31)
                {
                    temp2 += (char)c;
                    while ((str = reader.readLine()) != null) {
                        if (str.length() > 0) 
                        {
                            if(str.substring(2).equals(temp2))
                                {
                                temp += str.charAt(0);
                                temp2 = "";
                            }
                        }
                    }
                }
            }

        } catch(IOException e) {
            e.printStackTrace();
        }
        catch(Exception d) {
            d.printStackTrace();
        }

        return temp;
    }

    //print the characters and their codes
    public String traverseHuffmanTree(HuffTree huffTree) throws Exception
    {
        Stack s = new Stack();
        HuffBaseNode root = huffTree.root();
        String temp = "";
        temp += getCodes(root, s);
        return temp;
    }

    public String getCodes(HuffBaseNode n ,Stack s)
    {
        if(n.isLeaf())
        {
            char symbol = ((HuffLeafNode)n).value();
            String code = "";
            for(Object c : s)
                code += c;
            return (symbol + " " + code + "\n");
        }
        HuffBaseNode left = ((HuffInternalNode)(n)).left();
        HuffBaseNode right= ((HuffInternalNode)(n)).right();
        s.push('0');
        String temp = getCodes(left, s);
        s.pop(); 

        s.push('1');
        temp += getCodes(right, s);
        s.pop(); 
        return temp;

    }

}


