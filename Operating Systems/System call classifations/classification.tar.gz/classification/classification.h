int get_classification(const char* filename);
int set_classification(const char* filename, int new_class);
